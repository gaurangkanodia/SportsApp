package com.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateSchedule")
public class UpdateSchedule extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String starttime = null;
		String date = request.getParameter("date");
		String stime = request.getParameter("stime");
		String etime = request.getParameter("etime");
		String sport = request.getParameter("sport");
		String team1 = request.getParameter("team1");
		String team2 = request.getParameter("team2");
		String comment = request.getParameter("comment");
		String label = request.getParameter("label");
		if(stime!=null&&date!=null)
		{
			starttime = date+" "+stime+":00";
		}
		String endtime = date+" "+etime+":00";
		//PrintWriter out = response.getWriter();
		if(comment==null)
		{
			comment=" ";
		}
		
		System.out.println(date+stime+etime+sport+team1+team2+comment+label);
		try
		{
			Connection con = DatabaseConnector.getMySQLConnection();
			Statement stmt= con.createStatement();
			
			if(team1!=null&&team2!=null&&(starttime!=null)&&endtime!=null&&label!=null)
			{
				stmt.execute("insert into "+sport+" (team1,team2,sttime,endtime,score1,score2,label,comment) values('"+team1+"','"+team2+"','"+starttime+"','"+endtime+"',0,0,'"+label+"','"+comment+"');");
				response.sendRedirect("admin/updatesuccess.html");
			}
			else
			{
				response.sendRedirect("admin/updatefail.html");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	
		
	}

}
