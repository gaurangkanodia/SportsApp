package com.db;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String sport = request.getParameter("sport");
		String tname = request.getParameter("tname");
		String cname = request.getParameter("cname");
		String email = request.getParameter("email");
		String num = request.getParameter("num");
		
		sport.toLowerCase();
		
		PrintWriter out = response.getWriter();
		
		//out.print(num);
		try
		{
			Connection con = DatabaseConnector.getMySQLConnection();
			Statement stmt = con.createStatement();
			
			
			String query = "INSERT INTO "+sport+"register VALUES('"+tname+"','"+cname+"','"+num+"','"+email+"' )";
			
			
			int i = stmt.executeUpdate(query);
			stmt.execute("INSERT into "+sport+"leader values ('"+tname+"',0,0,0,0,0);");
			
			if(i>0)
			{
				response.sendRedirect("regsuccess.html");
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			response.sendRedirect("regfailure.html");
		}
		
		
	}

}
