package com.db;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		PrintWriter out = response.getWriter();
		ResultSet rs = null;
		
	try
	{
		Connection con = DatabaseConnector.getMySQLConnection();
		Statement stmt= con.createStatement();
		rs=stmt.executeQuery("select * from login where username='"+username+"' and password='"+password+"';");
		//System.out.println(rs);
		
		if(rs.next())//&&!(username.equals(null))&&!password.equals(null)))
		{
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			response.sendRedirect("admin/today.jsp");
		}
		else
		{
			out.print("Bad username or password.");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
		
	
}
