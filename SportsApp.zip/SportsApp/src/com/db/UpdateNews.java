package com.db;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/UpdateNews")
@MultipartConfig
public class UpdateNews extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		
		String heading = request.getParameter("heading");
		String story = request.getParameter("story");
		String img = request.getParameter("img");
		FileOutputStream fos=null;
	try
	{
	    Part filePart = request.getPart("img"); // Retrieves <input type="file" name="file">
	    String filename = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // MSIE fix.
	    InputStream filecontent = filePart.getInputStream();
	    System.out.println(new File(".").getCanonicalPath());
	    fos = new FileOutputStream(new File("../Myworkspace/SportsApp/WebContent/images/"+filename));
	    //D:\Eclipse\Myworkspace\SportsApp\WebContent\images
	    int i=0;
	    while((i=filecontent.read())!=-1)
	    {
	    	fos.write(i);
	    }
	    
	    Connection con = DatabaseConnector.getMySQLConnection();
		Statement stmt= con.createStatement();
		int bool = stmt.executeUpdate("insert into news (newsimage,newshead,newsstory) values('"+filename+"','"+heading+"','"+story+"')");
	    if(bool!=0)
	    {
	    	response.sendRedirect("admin/updatesuccess.html");
	    }
	    else
	    {
	    	response.sendRedirect("admin/updatefail.html");
	    }
	    
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		fos.flush();
		fos.close();
	}
		/*
		try
		{
			Connection con = DatabaseConnector.getMySQLConnection();
			Statement stmt= con.createStatement();
			stmt.execute("insert into news values('"+imgname+"','"+heading+"','"+story+"')");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}*/
	
	}

}
